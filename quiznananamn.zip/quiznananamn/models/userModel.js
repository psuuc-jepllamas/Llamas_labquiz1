const mongoose = require('mongoose')

const userSchema = new mongoose.Schema({
    username: {
        type: String,
        required: [true, "Username is required"],
        unique: true,
        trim: true
    },
    password: {
        type: String,
        required: [true, "Password is required"],
        minlength: [6, "Password must be at least 6 characters"]
    }
}, { timestamps: true })

userSchema.methods.comparePassword = async function(candidatePassword) {
    return this.password === candidatePassword
}

module.exports = mongoose.model('User', userSchema)