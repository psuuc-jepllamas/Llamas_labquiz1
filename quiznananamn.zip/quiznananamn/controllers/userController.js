const User = require('../models/userModel')

const getAll = async (req, res) => {
    const users = await User.find().select('username')
    res.render('index', { users })
}

const registerForm = (req, res) => {
    res.render('register', { formData: {}, errors: {} })
}

const register = async (req, res) => {
    try {
        await User.create(req.body)
        res.redirect('/users')
    } catch (err) {
        let errors = {}

        if (err.code === 11000) {
            errors.username = { message: 'Username already exists' }
        } else if (err.name === 'ValidationError') {
            Object.values(err.errors).forEach(({ properties }) => {
                errors[properties.path] = { message: properties.message }
            })
        }

        res.render('register', {
            formData: req.body,
            errors
        })
    }
}

const loginForm = (req, res) => {
    res.render('login', { formData: {}, errors: {} })
}

const login = async (req, res) => {
    let errors = {}
    let formData = { username: req.body.username || '' }

    try {
        const user = await User.findOne({ username: req.body.username })

        if (!user) {
            errors.general = { message: 'Invalid username or password' }
            return res.render('login', { formData, errors })
        }

        const isMatch = await user.comparePassword(req.body.password)
        if (!isMatch) {
            errors.general = { message: 'Invalid username or password' }
            return res.render('login', { formData, errors })
        }

        res.redirect('/users')

    } catch (err) {
        errors.general = { message: 'Server error' }
        res.render('login', { formData, errors })
    }
}

module.exports = { getAll, registerForm, register, loginForm, login }